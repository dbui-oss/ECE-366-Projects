module one_bit_full_adder(A, B, Cin, S, Cout);
  input A, B, Cin;
  output S, Cout;
  reg S, Cout;
  always @ (A or B or Cin)
  begin
    {Cout, S} = A + B + Cin;
  end 
  
endmodule